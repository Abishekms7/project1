README:

Pablo is subscription manager app that can be used to store user subscriptions.

The following are sample inputs and outputs of all the API's.

1. getCureencyList
Input:
No Input

Output example:
currency: [
{
	0: "1",
	1: "INR",
	2: "u20B9",
	3: "images/flags/india.png",
	id: "1",
	name: "INR",
	unicode: "u20B9",
	imageUrl: "images/flags/india.png"
}

2. 
*/
