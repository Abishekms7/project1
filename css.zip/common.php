<?php
	$additem = "Add to Stock";
	$viewitem = "View Sale";
	$edititem = "Edit Item";
	$deleteitem = "Delete Sale/Stock";
	$viewstock = "View Stock";
	$itementry = "Sell Item";
	$summary = "Summary";
	$rating = "Rate Coach";
?>