<?php
//$stat=mysqli_connect('localhost','root','pass','yuwa') or die("Error connecting to database");
$stat=mysqli_connect('localhost','yuwaroot','pT@UKUJn]9u+','yuwa') or die("Error connecting to database");
?>
