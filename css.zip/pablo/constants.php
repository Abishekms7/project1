<?php
//$stat=mysqli_connect('localhost','root','pass','pablo') or die("Error connecting to database");
$stat=mysqli_connect('localhost','yuwaroot','pT@UKUJn]9u+','yuwa') or die("Error connecting to database");
$domain = "http://yuwa-internal.xyz/pablo/";
$product = "Pablo";
$userImageDirectory = "images/users/";
$defaultImage = "default.jpeg";
$currency_table = "currency";
$popular_subscription_table = "popularsubscription";
$price_table = "price";
$user_images_table = "userimages";
$users_table = "users";
$user_subsciption_list_table = "user_subsciption_list";
?>
